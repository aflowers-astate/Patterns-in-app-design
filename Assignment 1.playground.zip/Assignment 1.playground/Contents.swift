import UIKit

var name = "Name: Andrew Flowers"
var age = 21
var homeTown = "Hometown: Newport, Arkansas"
var aboutMe = "I am quite unsure about my career goals, but I know I want to move to the city to work. One major idea I have is to combine my love for language learning with development and work at a company like Duolingo, Babbel, or Lingodeer. Alternatively, I am interested in eCommerce and webshops, so I could see myself helping brands build their online storefronts."

var bio = name + " Age: " + String(age) + " " + homeTown + " " + aboutMe
