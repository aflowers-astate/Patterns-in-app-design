//
//  OverviewViewController.swift
//  iOSCarAppFinal
//
//  Created by Andrew Flowers on 10/10/20.
//

import UIKit

class OverviewViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var nextPayment: UILabel!
    @IBAction func upcomingPaymentPress(_ sender: UIButton) {
        if(nextPayment.alpha == 0){
        nextPayment.alpha = 1
        } else {
            nextPayment.alpha = 0
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
